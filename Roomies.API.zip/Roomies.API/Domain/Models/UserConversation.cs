﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Roomies.API.Domain.Models
{
    /*public class UserConversation
    {
        public string UserId { set; get; }
        public string ConversationId { set; get; }
        public User User { set; get; }
        public Conversation Conversation { set; get; }

    }*/
}
