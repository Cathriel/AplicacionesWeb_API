﻿using Roomies.API.Domain.Models;
using Roomies.API.Domain.Services.Communications;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Roomies.API.Domain.Services
{
    //public interface IUserService
    //{
    //    Task<IEnumerable<User>> ListAsync();
    //    Task<IEnumerable<User>> ListByConversationIdAsync(int conversationId);
    //    Task<IEnumerable<User>> ListByPaymentMethodIdAsync(int paymentMethodId);
    //    Task<UserResponse> GetByIdAsync(int id);
    //    Task<UserResponse> SaveAsync(User user);
    //    Task<UserResponse> UpdateAsync(int id, User user);
    //    Task<UserResponse> DeleteAsync(int id);
    //}
}
