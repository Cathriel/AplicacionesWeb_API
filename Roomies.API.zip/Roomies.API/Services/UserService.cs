﻿using Roomies.API.Domain.Models;
using Roomies.API.Domain.Services;
using Roomies.API.Domain.Services.Communications;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Roomies.API.Services
{
//    public class UserService : IUserService
//    {
//        private readonly IUserRepository _userRepository;

//        public Task<UserResponse> DeleteAsync(int id)
//        {
//            throw new NotImplementedException();
//        }

//        public Task<UserResponse> GetByIdAsync(int id)
//        {
//            throw new NotImplementedException();
//        }

//        public Task<IEnumerable<User>> ListAsync()
//        {
//            throw new NotImplementedException();
//        }

//        public Task<IEnumerable<User>> ListByConversationIdAsync(int conversationId)
//        {
//            throw new NotImplementedException();
//        }

//        public Task<IEnumerable<User>> ListByPaymentMethodIdAsync(int paymentMethodId)
//        {
//            throw new NotImplementedException();
//        }

//        public Task<UserResponse> SaveAsync(User user)
//        {
//            throw new NotImplementedException();
//        }

//        public Task<UserResponse> UpdateAsync(int id, User user)
//        {
//            throw new NotImplementedException();
//        }
//    }
}
